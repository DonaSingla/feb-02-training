/// <reference path="pixi.js.d.ts" />
var main = /** @class */ (function () {
    function main() {
        this.canvasWidth = 800;
        this.canvasHeight = 600;
        this.app = new PIXI.Application(this.canvasWidth, this.canvasHeight);
        document.body.appendChild(this.app.view);
        this.app.renderer.backgroundColor = 0x061639;
        /* PIXI.loader
            .add('spineDude',"../assests/dude.png");
            .load()=>{
             this.onAssestsLoaded(this.loader,this.res)};

         this.container=new PIXI.Container();
         this.container.addChild(this.spineDude);*/
    }
    return main;
}());
