/// <reference path="pixi.js.d.ts" />

class main{
    protected app:any;
    protected container:any;
    protected loader:any;
    protected res:any;
    protected canvasWidth:number;
    protected canvasHeight:number;
    protected spineDude:any;

    constructor(){
          this.canvasWidth=800;
          this.canvasHeight=600;
         this.app = new PIXI.Application(this.canvasWidth,this.canvasHeight,);
         document.body.appendChild(this.app.view);
         this.app.renderer.backgroundColor = 0x061639;

        /* PIXI.loader
            .add('spineDude',"../assests/dude.png");
            .load()=>{
             this.onAssestsLoaded(this.loader,this.res)};  

         this.container=new PIXI.Container();
         this.container.addChild(this.spineDude);*/


      }
    /*onAssestsLoaded(loader,res):any{
        var spineDude = new PIXI.spine.Spine(res.spineboy.spineData);
        spineDude.x = this.app.screen.width / 2;
        spineDude.y = this.app.screen.height;
    
        spineDude.scale.set(1.5);
        this.app.stage.addChild(spineDude);
    }*/
}