var app = new PIXI.Application(window.innerWidth,window.innerHeight);
document.body.appendChild(app.view);
//app.view.style.display=block;
  let background,bg,rain,rg;
PIXI.loader

.add("images/spritesheet.json").load(onAssetsLoaded);

function onAssetsLoaded(){
    
      bg=PIXI.Texture.from("background.png");
      background=new PIXI.Sprite(bg);
      app.stage.addChild(background);

      staticBodies("objects/Rain.png",600,900);
      staticBodies("objects/Bus Bench.png",1070,500);
      staticBodies("objects/manhole/Manhole_01.png",563,430);
      staticBodies("objects/Hydrant0001.png",1520,300);
      staticBodies("objects/Fruitstand0001.png",400,800);


      var frames = [];
      for (var i = 1; i < 9; i++) {
          var val = i < 10 ? '0' + i : i;
          frames.push(PIXI.Texture.fromFrame("capguy_" + val +".png"));
      } 
      var anim = new PIXI.extras.AnimatedSprite(frames);
      anim.x = 100;
      anim.y = 800;
      anim.anchor.set(0.5);
      anim.animationSpeed = 0.5;
      anim.buttonMode=true;
      anim.interactive=true;
      app.stage.addChild(anim);
      anim.on('pointerdown', onClick);

      
      function onClick(){
        anim.play();
          app.ticker.add(delta=>gameLoop(delta));
      }
      function gameLoop(){
        //anim.rotation+=0.06;
        anim.x+=3; 
          if(anim.x==850){
            app.stage.removeChild(anim);
            app.stage.addChild(anim1);
          }
           }
      


      var frames1 = [];
      for (var i = 1; i < 9; i++) {
          var val = i < 10 ? '0' + i : i;
          frames1.push(PIXI.Texture.fromFrame("objects/manhole/Manhole_" + val +".png"));
      } 
      var anim1 = new PIXI.extras.AnimatedSprite(frames1);
      anim1.x = 850;
      anim1.y = 900;
      anim1.anchor.set(0.5);
      anim1.animationSpeed = 0.05;
      anim1.buttonMode=true;
      anim1.interactive=true;
      //anim1.loop=false;
      
     
      app.ticker.add(delta=>gameLoop1(delta));

      function gameLoop1(){
       anim1.play();
       anim1.loop = false;
      }
      
    }

    function staticBodies(textureId,x,y){
      rg=PIXI.Texture.fromFrame(textureId);
      rain=new PIXI.Sprite(rg);
      rain.x=x;
      rain.y=y;
      app.stage.addChild(rain);
    }


  
    