declare namespace IGPingPong{
    export interface iRigidBody{
     x:number;
     y:number;
     width:number;
     height:number;
     stage:any;
    }

}