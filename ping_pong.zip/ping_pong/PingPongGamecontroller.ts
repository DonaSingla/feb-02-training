namespace IGPingPong{
   export class PingPongGamecontroller  extends Gamecontroller  {
        
        app!:PIXI.Application;
       
        
        paddle1!: paddle;
        paddle2!: paddle;
        ball!: Ball;
        paddleTop!:Boundary;
        paddleRight!:Boundary;
        paddleBottom!:Boundary;
        paddleLeft!:Boundary;
        moveVelocityX:number=1.5;
        moveVelocityY:number=1.5;
        collider!:Collider;

        constructor() {
            super();
            this.start();
        
        }
        start() {

        this.ball = new Ball(350, 0, 15, this.app);
        this.paddle1 = new paddle(5,0,10,150,this.app);
        
        this.paddle2 = new paddle(785, 0, 10, 150, this.app);
        this.paddleTop= new Boundary(0,-5,this.canvasWidth,10,this.app);
        this.paddleLeft= new Boundary(795,0,10,this.canvasHeight,this.app);
        this.paddleBottom= new Boundary(0,595,this.canvasWidth,10,this.app);
        this.paddleRight=new Boundary(-5,0,10,this.canvasHeight,this.app);
        this.collider = new Collider();
        }
      
       update(delta:number){
          
                  
           this.ballMovement();
           this.paddle1Movement();
           this.paddle2Movement();
           this.handleCollision();   
             
        }
        
        ballMovement():any{
            this.ball.moveTo(this.moveVelocityX, this.moveVelocityY);  
        }

       paddle1Movement(): any {
        
        this.paddle1.moveTo(0,this.ball.y);}
        
         paddle2Movement(): any{
           let mousemove = this.app.renderer.plugins.interaction.mouse.global.y;
           if(mousemove < 0)
               mousemove =  0;
           if(mousemove > this.app.screen.height)
                mousemove = this.app.screen.height-this.paddle2.height;

                this.paddle2.y = mousemove;
                this.paddle2.graphics.position.y = mousemove;

           

        }

//////COLLISION //////
         handleCollision(): any{
               
            
                
         }

        }
    }
           
          
        
        
    
