namespace IGPingPong{
       
    export class Ball implements iRigidBody{
        public x:number;
        public y:number;
        public height:number;
        public width:number;
       
        public stage:any;
        public graphics = new PIXI.Graphics();

    constructor(x:number,y:number,radius:number,stage:any){
        this.x=x;
        this.y=y;
        this.height=2*radius;
        this.width=2*radius;
        this.stage=stage;
        this.drawBall();
       
    }
       drawBall():any{
               this.graphics.beginFill(0x64FFFF);
               this.graphics.drawCircle(this.x,this.y,this.width/2);
               this.graphics.endFill();
               this.stage.stage.addChild(this.graphics);
       }
       moveTo(x:number,y:number):void{
        this.x=x;
        this.y=y;
        this.graphics.position.x+=x;
        this.graphics.position.y+=y;
       }
    }
}