"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var IGPingPong;
(function (IGPingPong) {
    var Ball = /** @class */ (function () {
        function Ball(x, y, radius, stage) {
            this.graphics = new PIXI.Graphics();
            this.x = x;
            this.y = y;
            this.height = 2 * radius;
            this.width = 2 * radius;
            this.stage = stage;
            this.drawBall();
        }
        Ball.prototype.drawBall = function () {
            this.graphics.beginFill(0x64FFFF);
            this.graphics.drawCircle(this.x, this.y, this.width / 2);
            this.graphics.endFill();
            this.stage.stage.addChild(this.graphics);
        };
        Ball.prototype.moveTo = function (x, y) {
            this.x = x;
            this.y = y;
            this.graphics.position.x += x;
            this.graphics.position.y += y;
        };
        return Ball;
    }());
    IGPingPong.Ball = Ball;
})(IGPingPong || (IGPingPong = {}));
var IGPingPong;
(function (IGPingPong) {
    var Boundary = /** @class */ (function () {
        function Boundary(x, y, width, height, stage) {
            this.graphics = new PIXI.Graphics();
            this.x = x;
            this.y = y;
            this.width = width;
            this.height = height;
            this.stage = stage;
            this.drawBoundary();
        }
        Boundary.prototype.drawBoundary = function () {
            this.graphics.beginFill(0x251096);
            this.graphics.drawRect(this.x, this.y, this.width, this.height);
            this.graphics.endFill();
            this.stage.stage.addChild(this.graphics);
        };
        return Boundary;
    }());
    IGPingPong.Boundary = Boundary;
})(IGPingPong || (IGPingPong = {}));
var IGPingPong;
(function (IGPingPong) {
    var Collider = /** @class */ (function () {
        function Collider() {
        }
        Collider.prototype.isCollide = function (object1, object2, handler) {
            if (!(((object1.y + object1.height) < object2.y) ||
                ((object1.y + object1.height) > object2.y) ||
                ((object1.x + object1.width) < object2.x) ||
                ((object1.x + object1.width) > object2.x))) {
                handler();
            }
        };
        return Collider;
    }());
    IGPingPong.Collider = Collider;
})(IGPingPong || (IGPingPong = {}));
var IGPingPong;
(function (IGPingPong) {
    var Gamecontroller = /** @class */ (function () {
        function Gamecontroller() {
            this.canvasWidth = 0;
            this.canvasHeight = 0;
            this.canvasWidth = 800;
            this.canvasHeight = 600;
            this.app = new PIXI.Application(this.canvasWidth, this.canvasHeight);
            this.app.view.style.margin = "auto";
            this.app.view.style.display = "block";
            this.app.view.style.opacity = "0.7";
            document.body.appendChild(this.app.view);
            this.app.ticker.add(this.update.bind(this));
        }
        Gamecontroller.prototype.start = function () { };
        Gamecontroller.prototype.update = function (delta) { };
        return Gamecontroller;
    }());
    IGPingPong.Gamecontroller = Gamecontroller;
})(IGPingPong || (IGPingPong = {}));
var IGPingPong;
(function (IGPingPong) {
    var paddle = /** @class */ (function () {
        function paddle(x, y, width, height, stage) {
            this.graphics = new PIXI.Graphics();
            this.x = x;
            this.y = y;
            this.width = width;
            this.height = height;
            this.stage = stage;
            this.drawPaddle();
        }
        paddle.prototype.drawPaddle = function () {
            this.graphics.beginFill(0x261095);
            this.graphics.drawRect(this.x, this.y, this.width, this.height);
            this.graphics.endFill();
            this.stage.stage.addChild(this.graphics);
        };
        paddle.prototype.moveTo = function (x, y) {
            this.x = x;
            this.y = y;
            this.graphics.position.x += x;
            this.graphics.position.y += y;
        };
        return paddle;
    }());
    IGPingPong.paddle = paddle;
})(IGPingPong || (IGPingPong = {}));
var IGPingPong;
(function (IGPingPong) {
    var PingPongGamecontroller = /** @class */ (function (_super) {
        __extends(PingPongGamecontroller, _super);
        function PingPongGamecontroller() {
            var _this = _super.call(this) || this;
            _this.moveVelocityX = 1.5;
            _this.moveVelocityY = 1.5;
            _this.start();
            return _this;
        }
        PingPongGamecontroller.prototype.start = function () {
            this.ball = new IGPingPong.Ball(350, 0, 15, this.app);
            this.paddle1 = new IGPingPong.paddle(5, 0, 10, 150, this.app);
            this.paddle2 = new IGPingPong.paddle(785, 0, 10, 150, this.app);
            this.paddleTop = new IGPingPong.Boundary(0, -5, this.canvasWidth, 10, this.app);
            this.paddleLeft = new IGPingPong.Boundary(795, 0, 10, this.canvasHeight, this.app);
            this.paddleBottom = new IGPingPong.Boundary(0, 595, this.canvasWidth, 10, this.app);
            this.paddleRight = new IGPingPong.Boundary(-5, 0, 10, this.canvasHeight, this.app);
            this.collider = new IGPingPong.Collider();
        };
        PingPongGamecontroller.prototype.update = function (delta) {
            this.ballMovement();
            this.paddle1Movement();
            this.paddle2Movement();
            this.handleCollision();
        };
        PingPongGamecontroller.prototype.ballMovement = function () {
            this.ball.moveTo(this.moveVelocityX, this.moveVelocityY);
        };
        PingPongGamecontroller.prototype.paddle1Movement = function () {
            this.paddle1.moveTo(0, this.ball.y);
        };
        PingPongGamecontroller.prototype.paddle2Movement = function () {
            var mousemove = this.app.renderer.plugins.interaction.mouse.global.y;
            if (mousemove < 0)
                mousemove = 0;
            if (mousemove > this.app.screen.height)
                mousemove = this.app.screen.height - this.paddle2.height;
            this.paddle2.y = mousemove;
            this.paddle2.graphics.position.y = mousemove;
        };
        //////COLLISION //////
        PingPongGamecontroller.prototype.handleCollision = function () {
        };
        return PingPongGamecontroller;
    }(IGPingPong.Gamecontroller));
    IGPingPong.PingPongGamecontroller = PingPongGamecontroller;
})(IGPingPong || (IGPingPong = {}));
/// <reference path="pixi.js.d.ts" />
var IGPingPong;
(function (IGPingPong) {
    var VMaingame = /** @class */ (function () {
        function VMaingame() {
            this.gc = new IGPingPong.PingPongGamecontroller();
        }
        return VMaingame;
    }());
    IGPingPong.VMaingame = VMaingame;
    var ob1 = new VMaingame();
})(IGPingPong || (IGPingPong = {}));
