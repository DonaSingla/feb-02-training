namespace IGPingPong{

    export class paddle implements iRigidBody{
           public x:number;
           public y:number;
           public width:number;
           public height:number;
           public stage:any;
           public graphics  = new PIXI.Graphics();

        constructor(x:number,y:number,width:number,height:number,stage:any)
        {
            this.x=x;
            this.y=y;
            this.width=width;
            this.height=height;
            this.stage=stage;
            this.drawPaddle();
        }
        drawPaddle():any{
               
                 
            this.graphics.beginFill(0x261095);
            this.graphics.drawRect(this.x,this.y,this.width,this.height);
            this.graphics.endFill();
            this.stage.stage.addChild(this.graphics);

        }
        moveTo(x:number,y:number):void{
            this.x=x;
            this.y=y;
            this.graphics.position.x += x;
            this.graphics.position.y += y;
           
        }
    }
}
