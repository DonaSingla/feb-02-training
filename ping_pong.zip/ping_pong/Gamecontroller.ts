namespace IGPingPong{

    export class Gamecontroller{
        public canvasWidth:number=0;
        public canvasHeight:number=0;
        app:PIXI.Application;
        constructor(){
            this.canvasWidth=800;
            this.canvasHeight=600;
            this.app = new PIXI.Application(this.canvasWidth,this.canvasHeight);
            this.app.view.style.margin ="auto";
            this.app.view.style.display="block";
            this.app.view.style.opacity="0.7";
            
            document.body.appendChild(this.app.view);
           this.app.ticker.add(this.update.bind(this));
        

    
             
        }
        start():void{}
        update(delta: number):void{}
    }
}