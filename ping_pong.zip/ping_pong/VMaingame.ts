/// <reference path="pixi.js.d.ts" />


namespace IGPingPong{
     export class VMaingame {
        
          gc: PingPongGamecontroller; 
            constructor(){
                 this.gc = new PingPongGamecontroller();
            }
             
            }
            var ob1 = new VMaingame();
        
          }


